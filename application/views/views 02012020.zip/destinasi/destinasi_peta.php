<html>
<head><?php echo $map['js']; ?></head>
<body><?php echo $map['html']; ?></body>
</html>