<ul class="navbar-nav mr-auto">
	        	<li class="nav-item"><a href="<?php echo base_url()?>" class="nav-link pl-0">Home</a></li>
	        	<li class="nav-item"><a href="<?php echo base_url().'Home/produk_anggota'?>" class="nav-link">Produk</a>
	        		<!-- <ul class="dropdown-item"><a href="#" class="dropdown-item">Daftar Produk</a></ul> -->
	        	</li>
	        </ul>